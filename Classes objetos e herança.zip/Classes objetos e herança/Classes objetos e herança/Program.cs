﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Classes_objetos_e_herança
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Carro carro_Mercedes = new Carro();
            
            
            carro_Mercedes.marca = "Mercedes";
            carro_Mercedes.nome = "Amg";
            carro_Mercedes.cor = "Roxo";
            carro_Mercedes.km = 120000;
            carro_Mercedes.ano = 2018;
            carro_Mercedes.velocidadecarro = 0;
            carro_Mercedes.velocidadecarrom = 220;
            carro_Mercedes.motor = 5;
            carro_Mercedes.travoes = 3;
            carro_Mercedes.acelarador = 4;
            carro_Mercedes.transmissao = 4;
            carro_Mercedes.blindagem = 4; 

            Console.WriteLine("Marca: " + carro_Mercedes.marca);
            Console.WriteLine("Modelo: " + carro_Mercedes.nome);
            Console.WriteLine("Cor: " + carro_Mercedes.cor);
            Console.WriteLine("K/m do carro: " + carro_Mercedes.km);
            Console.WriteLine("Ano de fabricação: " + carro_Mercedes.ano);
            Console.WriteLine("Velocidade Máxima: "+ carro_Mercedes.velocidadecarrom);
            Console.WriteLine("Níveis do carro: ");
            Console.WriteLine("Nível do Motor: " + carro_Mercedes.motor + ", Bom motor");
            Console.WriteLine("Nível dos Traões: " + carro_Mercedes.travoes + ", Mediano o travão, consegue travar, mas se tiver com muita velocidade não ");
            Console.WriteLine("Nível do Acelarador: " + carro_Mercedes.acelarador + ", Bom acelerador, em corridas dava-se bem");
            Console.WriteLine("Nível da Transmissão: " + carro_Mercedes.transmissao + ", Boa transmissão, consegue chegar a uma velocidade boa");
            Console.WriteLine("Nível da Blindagem: " + carro_Mercedes.blindagem + ", Boa blindagem, mas faz com que o carro seja pesado");

            Console.WriteLine("-----------------");
           
            Console.WriteLine("TEST DRIVE: O carro começou acelarar:");
            carro_Mercedes.acelarar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            carro_Mercedes.acelarar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            carro_Mercedes.acelarar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            carro_Mercedes.acelarar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            Console.WriteLine("O carro travou a fundo, velocidade atual: "+ carro_Mercedes.velocidadecarro );
            carro_Mercedes.travar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            carro_Mercedes.travar();
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            carro_Mercedes.travar();
            carro_Mercedes.travar();
            carro_Mercedes.travar();
            Console.WriteLine("O carro bateu");
            Console.WriteLine("+ K/M...: " + carro_Mercedes.velocidadecarro);
            Console.WriteLine("O condutor morreu.");


            Console.ReadLine();
        }
    }
}
