﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes_objetos_e_herança
{
    public class Class1
    {
      public string marca;
      public string nome;
      public string cor;
      public int km;
      public int ano;
      public int velocidadecarro;
      public int velocidadecarrom;

        public void acelarar ()
        {
            velocidadecarro += 20;
            if (velocidadecarro > velocidadecarrom)
            {
                velocidadecarro = velocidadecarrom;
            }
        }

        public void travar()
        {
            velocidadecarro -= 20;
            if (velocidadecarro < 0)
            {
                velocidadecarro = 0;
            }
        }

    }

    public class Carro : Class1
    {
        public int motor;
        public int travoes;
        public int acelarador;
        public int transmissao;
        public int blindagem;

    }

}
